<?php include "cabecalho.php" ?>
<body>
<nav class="red accent-4">
    <div class="nav-wrapper">
    <ul id="nav-mobile" class="right">
        <li><a href="index.php">Login</a></li>
      </ul>
      <div class= "nav-header center">
        <h1>CGFLIX</h1>
    </div>
    </div>
    <div class="nav-content">
      <ul class="tabs tabs-transparent black">
      </ul>
    </div>
</nav>

<main class="container-fluide" style="margin-top:50px">
<div class="row">
    <div class="col s6 offset-s3">
        <div class="card">
            <div class="card-content">

<div class="row">
    <form action= "validacadastro.php" method="POST" class="col s12">
      <div class="row">
        <div class="input-field col s6">
          <input placeholder="Digite seu nome"  name="nome" id="first_name" type="text" class="validate">
          <label for="first_name">Nome Completo</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <input id="password"  name="senha" type="password" class="validate">
          <label for="password">Senha</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <input id="email" name="email" type="email" class="validate">
          <label for="email">Email</label>
        </div>
      </div>
      <div class="card-action">
                <a class="btn waves-effect waves-light grey" href="index.php">Cancelar</a>
                <input type="submit" class="btn waves-effect waves-light red" value="Confirmar" name="Confirmar">
            </div>
    </form>

    


  </div>