<?php
        $mysqli = new mysqli("localhost", "root", "", "db",3307);

        if (mysqli_connect_errno()) {
            echo ( "Erro de conexão: " . mysqli_connect_error()); 
            exit();
        } 
?>