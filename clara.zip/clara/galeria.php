<?php include "cabecalho.php" ?>

<?php
$filme=
["titulo"=>"Homem-Aranha", 
"nota"=>9.7 ,
"sinopse"=>"",
"poster"=>"https://www.themoviedb.org/t/p/w300/fVzXp3NwovUlLe7fvoRynCmBPNc.jpg"
];

$filme2=
["titulo"=>"Como eu era antes de você", 
"nota"=>8.7 ,
"sinopse"=>"",
"poster"=>"https://www.themoviedb.org/t/p/original/3WMts1hmXf7pjqtw7IPtTCf1OYw.jpg"
];

$filme3=
["titulo"=>"Doutor-Estranho", 
"nota"=>8.0 ,
"sinopse"=>"",
"poster"=>"https://www.themoviedb.org/t/p/original/boIgXXUhw5O3oVkhXsE6SJZkmYo.jpg"
];

$filme4=
["titulo"=>"Superação: O Milagre da Fé", 
"nota"=>9.0 ,
"sinopse"=>"",
"poster"=>"https://www.themoviedb.org/t/p/w300/qNrL1DAHxLA5Bh5sc2xMWJ1pHa8.jpg"
];

$filme5=
["titulo"=>"A cabana", 
"nota"=>8.7 ,
"sinopse"=>"",
"poster"=>"https://www.themoviedb.org/t/p/w300/yf2WNfO1b0E1IcJDLUiGj7ccKRm.jpg"
];

$filme6=
["titulo"=>"Avatar", 
"nota"=>8.7 ,
"sinopse"=>"",
"poster"=>"https://www.themoviedb.org/t/p/w300/8x4TSGxaIIzTgQXyplBn1Y8mjlX.jpg"
];

$filme7=
["titulo"=>"Viúva-Negra", 
"nota"=>8.5 ,
"sinopse"=>"",
"poster"=>"https://www.themoviedb.org/t/p/original/rKq1Vlw0Bqe2EEvdmIkkkgPQAGf.jpg"
];

$filme8=
["titulo"=>"Minions 2", 
"nota"=>9.4 ,
"sinopse"=>"",
"poster"=>"https://www.themoviedb.org/t/p/original/tzFAboMUGJKoPQEtlxfxbbYsSWa.jpg"
];

$filmes=[$filme,$filme2,$filme3,$filme4,$filme5,$filme6,$filme7,$filme8]

?>

<body>
<nav class="red accent-4">
    <div class="nav-wrapper">
    <ul id="nav-mobile" class="right">
        <li><a href="galeria.php">Galeria</a></li>
        <li><a href="index.php">Sair</a></li>
      </ul>

      
      <div class= "nav-header center">
        <h1>CGFLIX</h1>
    </div>
    </div>
    <div class="nav-content">
      <ul class="tabs tabs-transparent black">

      </ul>
    </div>
  </nav>
     <main class="container-fluide" style="margin-top:50px">
     <div class="row">
          <?php foreach($filmes as $filme) : ?>
        <div class="col s3">
        <div class="card">
      <div class="card-image">
        <img src="<?= $filme["poster"]?>">
        <a class="btn-floating halfway-fab waves-effect waves-light red">
          <i class="material-icons">favorite_border</i>
        </a>
      </div>
      <div class="card-content">
        <p class="valign-wrapper">
              <i class="material-icons amber-text">star</i><?= $filme["nota"]?>
            </p>
        <span class="card-title"><?= $filme["titulo"]?></span>
        <p><?= $filme["sinopse"]?></p>
      </div>
      
      </div>
      
        </div>
        <?php endforeach ?>
       
     
</main>
   
    
</body>
</html>