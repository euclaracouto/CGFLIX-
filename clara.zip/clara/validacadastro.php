<?php
include 'conexao.php';
$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];

$sql ="INSERT INTO LOGIN ( nome, email, senha) VALUES( '$nome', '$email', '$senha')";

$mysqli->query($sql); // efetua o cadastro
if ($mysqli->insert_id == TRUE) {
?>
<script type="text/javascript">
alert("Cadastrado com Sucesso! ");
</script>
<?php
}
$mysqli->close();


header("location: index.php");

?>