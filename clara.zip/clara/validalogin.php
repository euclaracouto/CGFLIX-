<?php
include 'conexao.php';
$email = $_POST["email"];
$senha = $_POST["senha"];

$sql ="SELECT * FROM login where email='$email' and senha='$senha' ";

$result = $mysqli->query($sql); // gera consulta
$row = $result->num_rows; // conta numero de linhas


if($row == 0) {
echo "<h2>Usuário/Senha inválidos</h2>";
header("Refresh: 1; url=index.php");
}
else { //PEGA OS DADOS

echo "<h2>Usuário logado no sistema</h2>";
header("Refresh: 1; url=galeria.php"); // chamar menu principal
}
?>
